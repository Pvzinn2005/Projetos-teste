// trafficLight.test.js
const fs = require('fs');
const path = require('path');

let img;
let buttons;

beforeEach(() => {
    // Carregar o HTML necessário para o teste
    document.body.innerHTML = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
    
    img = document.getElementById('img');
    buttons = document.getElementById('buttons');
    
    // Resetar o estado antes de cada teste
    colorIndex = 0;
    clearInterval(intervalId);
});

test('should turn on red light', () => {
    buttons.querySelector('#red').click();
    expect(img.src).toContain('vermelho.png');
});

test('should turn on yellow light', () => {
    buttons.querySelector('#yellow').click();
    expect(img.src).toContain('amarelo.png');
});

test('should turn on green light', () => {
    buttons.querySelector('#green').click();
    expect(img.src).toContain('verde.png');
});

test('should switch to automatic mode', () => {
    jest.useFakeTimers(); // Usar timers fake para simular o intervalo

    buttons.querySelector('#automatic').click();
    expect(buttons.children.automatic.id).toBe('stop');

    // Avançar o tempo simulado
    jest.advanceTimersByTime(1000);
    
    expect(img.src).toContain('verde.png'); // Depois de 1 segundo, deve ser verde
    jest.advanceTimersByTime(1000);
    expect(img.src).toContain('vermelho.png'); // Depois de 2 segundos, deve ser vermelho
    jest.advanceTimersByTime(1000);
    expect(img.src).toContain('amarelo.png'); // Depois de 3 segundos, deve ser amarelo

    // Parar o automático
    buttons.querySelector('#stop').click();
    expect(buttons.children.stop.id).toBe('automatic');
});

afterAll(() => {
    jest.useRealTimers();
});
